let listaDeAmigos = [];
const lista = document.getElementById("listaDeAmigos");
const inputNome = document.getElementById("amigo");
const resultado = document.getElementById("resultado");

function adicionarAmigo() {
    const nomeAmigo = inputNome.value.trim();

    if (!nomeAmigo) {
        alert("Por favor, digite um nome válido!")
        return
    }

    if (listaDeAmigos.includes(nomeAmigo)) { // se o nome for igual a um que já esteja na lista...
        alert("Esse amigo já foi incluido.");
        return
    }

    listaDeAmigos.push(nomeAmigo); // coloca o nome na lista
    atualizarLista()
    inputNome.value = ""; // Limpa o input
}

function atualizarLista() {
    lista.innerHTML = "";  // Limpa a lista antes de atualizar

    listaDeAmigos.forEach((amigo, index) => {
        const item = document.createElement("li");
        item.textContent = amigo;

        // Criação do botão para remover nomes
        const botaoRemover = document.createElement("button");
        botaoRemover.textContent = "Excluir";
        botaoRemover.classList.add("button-remove"); // Adiciona a classe "button-remove"
        botaoRemover.onclick = () => removerAmigo(index);

        item.appendChild(botaoRemover);
        lista.appendChild(item);
    });
}


function removerAmigo(index) {
    listaDeAmigos.splice(index, 1);
    atualizarLista();
}

function sortearAmigo() {
    if (listaDeAmigos.length == 0) {
        alert("Adicione pelo menos um amigo para sortear.");
        return;
    }

    const amigoSorteado = listaDeAmigos[Math.floor(Math.random() * listaDeAmigos.length)];
    resultado.innerHTML = `<li>O Amigo secreto sorteado é: <strong>${amigoSorteado}</strong></li>`;
}

function limparLista() {
    listaDeAmigos = [];
    atualizarLista();
    resultado.innerHTML = "";
}

function reiniciarSorteio() {
    listaDeAmigos = [];
    resultado.innerHTML = "";
    lista.innerHTML = "";
    alert("O jogo foi reiniciado.")
}


/* ===== Função nova: gerarSugestoesPresentes() =====
   Gera 3 sugestões de presente para cada nome presente em listaDeAmigos,
   mostra cards bonitos e permite copiar as sugestões para a área de transferência.
*/
function gerarSugestoesPresentes() {
    if (!Array.isArray(listaDeAmigos) || listaDeAmigos.length === 0) {
        alert("Adicione pelo menos um amigo na lista antes de gerar sugestões.");
        return;
    }

    const presentes = [
        "Caneca personalizada com emoji",
        "Cartão-presente digital",
        "Meias divertidas",
        "Planta pequena (suculenta)",
        "Livro de bolso",
        "Porta-copos criativos",
        "Camiseta com estampa engraçada",
        "Chaveiro personalizado",
        "Kit de chocolates gourmet",
        "Luminária LED portátil",
        "Bloco de notas adesivas divertidas",
        "Jogo de cartas rápido",
        "Fone de ouvido simples",
        "Caderno de capa colorida",
        "Vale-um-jantar caseiro"
    ];

    function escolherN(arr, n) {
        const copy = arr.slice();
        const escolhidos = [];
        while (escolhidos.length < n && copy.length) {
            const idx = Math.floor(Math.random() * copy.length);
            escolhidos.push(copy.splice(idx,1)[0]);
        }
        return escolhidos;
    }

    // Cria/obtém o container de sugestões
    let container = document.getElementById("sugestoes");
    if (!container) {
        container = document.createElement("div");
        container.id = "sugestoes";
        container.className = "sugestoes-container";
        if (resultado && resultado.parentNode) {
            resultado.parentNode.insertBefore(container, resultado.nextSibling);
        } else {
            document.body.appendChild(container);
        }
    } else {
        container.innerHTML = ""; // limpa se já existir
    }

    // Para cada amigo, cria um card com 3 sugestões e botões "Copiar" e "Outra sugestão"
    listaDeAmigos.forEach((nome) => {
        const escolhas = escolherN(presentes, 3);
        const card = document.createElement("div");
        card.className = "sugestao-card";
        card.innerHTML = `
            <h3 class="sugestao-nome">${nome}</h3>
            <ul class="sugestao-list">
                ${escolhas.map(item => `<li>${item}</li>`).join('')}
            </ul>
            <div class="sugestao-actions">
                <button type="button" class="btn-copiar">Copiar</button>
                <button type="button" class="btn-surpresa">Outra sugestão</button>
            </div>
        `;
        container.appendChild(card);

        // evento copiar: sempre lê o conteúdo atual do card (por isso não usa a variável 'escolhas' diretamente)
        const btnCopiar = card.querySelector('.btn-copiar');
        btnCopiar.addEventListener('click', () => {
            const itens = Array.from(card.querySelectorAll('.sugestao-list li')).map(li => li.textContent);
            const texto = `${nome} — Sugestões: ${itens.join(', ')}`;
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(texto).then(() => {
                    alert('Sugestões copiadas para a área de transferência!');
                }).catch(() => {
                    prompt('Copie manualmente:', texto);
                });
            } else {
                prompt('Copie manualmente:', texto);
            }
        });

        // evento "Outra sugestão": substitui a lista por 3 novas sugestões
        const btnOutra = card.querySelector('.btn-surpresa');
        btnOutra.addEventListener('click', () => {
            const novas = escolherN(presentes, 3);
            card.querySelector('.sugestao-list').innerHTML = novas.map(i => `<li>${i}</li>`).join('');
        });
    });

    // Rola suavemente até as sugestões
    container.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

